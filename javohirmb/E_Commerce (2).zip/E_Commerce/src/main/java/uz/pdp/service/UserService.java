package uz.pdp.service;

public class UserService {
    private static final String fileName = "./Resources/users";
}
