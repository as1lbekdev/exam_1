package uz.pdp.model;

public enum UserType {
    ADMIN, USER
}
