package uz.pdp.service;

public abstract class BaseService {

}
