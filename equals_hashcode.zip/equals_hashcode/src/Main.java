import java.util.*;

public class Main {
    public static void main(String[] args) {
//        Integer i = new Integer(1009);
//        Integer j = new Integer(1009);
//
//        System.out.println(i.equals(j));
//        System.out.println(i.hashCode());
//        System.out.println(j.hashCode());


//        String s1 = new String("A");
//        String s2 = new String("A");
//
//        System.out.println(s1 == s2);
//        System.out.println(s1.equals(s2));
//        System.out.println(s1.hashCode());
//        System.out.println(s2.hashCode());

//        User user1 = new User(1, "Akhror");
//        User user2 = new User(1, "Sardor");
//
//        System.out.println(user1 == user2);
//        System.out.println(user1.equals(user2));
//
//        System.out.println(Objects.equals(user2, user1));
//        System.out.println(user1.hashCode());
//        System.out.println(user2.hashCode());


//        Map<String, Integer> nameToAgeMap = new HashMap<>();
//        nameToAgeMap.put("Sharof", 21);
//        nameToAgeMap.put("Sarvar", 23);
//        System.out.println(nameToAgeMap);
//        System.out.println(nameToAgeMap.getOrDefault("Sarvar", 29203));
//
//        System.out.println(nameToAgeMap.get("Sharof"));
//        System.out.println(nameToAgeMap);
//        nameToAgeMap.put("Sharof", 300);
//        System.out.println(nameToAgeMap.get("Sharof"));
//
//        for (Map.Entry<String, Integer> map: nameToAgeMap.entrySet()) {
//            System.out.println(map.getKey());
//            System.out.println(map.getValue());
//        }

//        MyHashMap<String, Integer> myHashMap = new MyHashMap<>();
//        myHashMap.put("Sharof", 10);
//        myHashMap.put("Pahlavon", 100);
//        myHashMap.put("Sharof", 1000);
//
//        myHashMap.print();
//        myHashMap.remove("Sharof");
//        myHashMap.print();

//        Map<String, Integer> map = new TreeMap<>();
//        map.put("Dushanba", 1);
//        map.put("Seshanba", 2);
//        map.put("Chorshanba", 3);
//        map.put("Payshanba", 4);
//        map.put("Juma", 5);
//        map.put("Shanba", 6);
//        map.put("Yakshanba", 7);
//        map.put("Chorshbnba", 3);
//        System.out.println(map);

        Set<String> sets = new TreeSet<>();
        sets.add("A");
        sets.add("K");
        sets.add("B");
        sets.add("L");
        sets.add("P");
        System.out.println(sets.contains("PP"));
        sets.remove("P");
        System.out.println(sets);

//        MySet<String> sets = new MySet<>();
//        sets.add("Akhror");
//        sets.add("Akhrorbek");
//        sets.add("Akhrorjon");
//        sets.add("Akhrorxon");
//        sets.add("Akhrorxon");
//
//        sets.print();
//        System.out.println(sets.contains("Akhrorxonm"));
    }
}